import matplotlib.pyplot as plt
import numpy as np
import random

# 1ST STEP 
Length = random.randint(50, 200)
Breath = Length / 6.5
T = Breath / 3.5
Cb = random.uniform(0.55, 0.85)

#soru = input(f"What is the underwater volume and Buoyancy Force of the ship \n"
#	"which is {Length} meter length, {Breath} meter breath, {T} meters draft and Cb is {Cb}?")

UwV = Length * Breath * T * Cb

#####################################
# 2ND STEP
# Waterlines and Frame Numbers lists
w1 = [0, 0.3, 1, 2, 3, 4, 5, 6] #* T / 4
pn = [0, 0.5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 9.5, 10] # * Length / 10

waterlines = [] # Ödevde gösterildiği üzere değerleri düzenliyoruz. Array şeklinde de yapabilirsiniz.
frame_numbers = []
for i in w1:
	i *= T / 4
	waterlines.append(i)
for j in pn:
	j *= Length / 10
	frame_numbers.append(j)
#####################################
# Reading s60.txt, correcting and extracting lines
file = open("s60.txt")

# Waterlines plot preprocessing
listeler = []
for line in file.readlines():
	line = (line.replace("\n", "")).split(" ") # Satırlar arası virgül yok, onun yerine boşluk var. Ayrıca sonda \n var onu kaldırıyoruz.
	line = [float(value) for value in line] # Aralardaki boşlukları split ederek otomatik olarak virgülle ayırmış oluyoruz. Ancak bu sefer de
	listeler.append(line) # aldığımız değerler string ifadeler oluyor. Float hale getirmek için üst satırdaki kodu yazıyoruz ve listelere ekliyoruz.
listeler_array = np.array(listeler) # ilk 6 satırı -1 ile çarpmak listeye göre daha kolay olduğu için array tipine  dönüştürüyoruz.
for i in range(6):
	listeler_array[i] = listeler_array[i] * -1

#Cross Section plot preprocessing
list_13 = [] # s60.txt dosyası her biri 8 değer içeren 13 satırdan oluşuyor cross section plot için her biri 13 değer içeren 8 satırlara dönüştürmeliyiz.
for i in range(8):
	for j in range(13):
		list_13.append(listeler[j][i]) # 43-46 satırları her biri 13 değer içeren 8 satırlık bir taslak yapıyor ancak satırları belirtmiyor. 
liste_all = [list_13[x:x+13] for x in range(0, len(list_13), 13)] # Bunu yapabilmek için her 13 değerde bir, bir liste oluşturuyoruz.
# Şu anda liste_all da 8 tane her biri 13 değerlik listeler var. İstediğimizi yapmış olduk.
file.close()

##################################################################
# Plotting
fig, axs = plt.subplots(2, figsize=(10,7))
fig.suptitle('Graphs')
# fig.figsize(10,7) # doesnt work
# Waterlines Plot
for liste in listeler_array: 	
	axs[0].plot(liste, waterlines)
# Cross Section Plot
for liste in liste_all:
	axs[1].plot(frame_numbers, liste)
plt.show()